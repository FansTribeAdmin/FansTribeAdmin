import '../backend/backend.dart';
import '../flutter_flow/flutter_flow_icon_button.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_toggle_icon.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../generate_fancode_page/generate_fancode_page_widget.dart';
import '../single_celeb_page/single_celeb_page_widget.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';

class FancodeStatusPageWidget extends StatefulWidget {
  const FancodeStatusPageWidget({Key key}) : super(key: key);

  @override
  _FancodeStatusPageWidgetState createState() =>
      _FancodeStatusPageWidgetState();
}

class _FancodeStatusPageWidgetState extends State<FancodeStatusPageWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: FlutterFlowTheme.of(context).tertiaryColor,
        automaticallyImplyLeading: false,
        leading: FlutterFlowIconButton(
          borderColor: Colors.transparent,
          borderRadius: 30,
          borderWidth: 1,
          buttonSize: 60,
          icon: Icon(
            Icons.arrow_back_rounded,
            color: Colors.white,
            size: 30,
          ),
          onPressed: () async {
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Celeb Code List',
          style: FlutterFlowTheme.of(context).title2.override(
                fontFamily: 'Lato',
                color: Colors.white,
                fontSize: 22,
              ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 2,
      ),
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => GenerateFancodePageWidget(),
            ),
          );
        },
        backgroundColor: FlutterFlowTheme.of(context).secondaryColor,
        icon: Icon(
          Icons.add_box,
        ),
        elevation: 8,
        label: Text(
          'New Code',
          style: FlutterFlowTheme.of(context).bodyText1.override(
                fontFamily: 'Lato',
                color: FlutterFlowTheme.of(context).primaryBackground,
              ),
        ),
      ),
      body: SafeArea(
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(12, 0, 12, 0),
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                  child: Row(
                    mainAxisSize: MainAxisSize.max,
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        flex: 3,
                        child: Text(
                          'Celeb',
                          style: FlutterFlowTheme.of(context).bodyText1,
                        ),
                      ),
                      Expanded(
                        flex: 2,
                        child: Text(
                          'Code',
                          style: FlutterFlowTheme.of(context).bodyText1,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Used',
                          style: FlutterFlowTheme.of(context).bodyText1,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          'Status',
                          style: FlutterFlowTheme.of(context).bodyText1,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                    child: StreamBuilder<List<FanscodeRecord>>(
                      stream: queryFanscodeRecord(),
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50,
                              height: 50,
                              child: CircularProgressIndicator(
                                color:
                                    FlutterFlowTheme.of(context).primaryColor,
                              ),
                            ),
                          );
                        }
                        List<FanscodeRecord> listViewFanscodeRecordList =
                            snapshot.data;
                        return ListView.builder(
                          padding: EdgeInsets.zero,
                          shrinkWrap: true,
                          scrollDirection: Axis.vertical,
                          itemCount: listViewFanscodeRecordList.length,
                          itemBuilder: (context, listViewIndex) {
                            final listViewFanscodeRecord =
                                listViewFanscodeRecordList[listViewIndex];
                            return Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Expanded(
                                  flex: 3,
                                  child: StreamBuilder<CelebsRecord>(
                                    stream: CelebsRecord.getDocument(
                                        listViewFanscodeRecord.celebUid),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 50,
                                            height: 50,
                                            child: CircularProgressIndicator(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primaryColor,
                                            ),
                                          ),
                                        );
                                      }
                                      final textCelebsRecord = snapshot.data;
                                      return InkWell(
                                        onTap: () async {
                                          await Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) =>
                                                  SingleCelebPageWidget(
                                                celebId:
                                                    textCelebsRecord.reference,
                                              ),
                                            ),
                                          );
                                        },
                                        child: Text(
                                          textCelebsRecord.celebName,
                                          style: FlutterFlowTheme.of(context)
                                              .bodyText1,
                                        ),
                                      );
                                    },
                                  ),
                                ),
                                Expanded(
                                  flex: 2,
                                  child: Text(
                                    listViewFanscodeRecord.code,
                                    style:
                                        FlutterFlowTheme.of(context).bodyText1,
                                  ),
                                ),
                                Expanded(
                                  child: Text(
                                    listViewFanscodeRecord.usedCount.toString(),
                                    style:
                                        FlutterFlowTheme.of(context).bodyText1,
                                  ),
                                ),
                                Expanded(
                                  child: ToggleIcon(
                                    onPressed: () async {
                                      final fanscodeUpdateData =
                                          createFanscodeRecordData(
                                        isActive:
                                            !listViewFanscodeRecord.isActive,
                                      );
                                      await listViewFanscodeRecord.reference
                                          .update(fanscodeUpdateData);
                                    },
                                    value: listViewFanscodeRecord.isActive,
                                    onIcon: FaIcon(
                                      FontAwesomeIcons.solidCircle,
                                      color: Color(0xFF00FF1E),
                                      size: 25,
                                    ),
                                    offIcon: FaIcon(
                                      FontAwesomeIcons.solidCircle,
                                      color: Color(0xFFFF0000),
                                      size: 25,
                                    ),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
