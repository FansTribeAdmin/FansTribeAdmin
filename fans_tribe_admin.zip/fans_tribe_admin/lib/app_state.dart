import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'flutter_flow/lat_lng.dart';

class FFAppState {
  static final FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal() {
    initializePersistedState();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _sectionList = prefs.getStringList('ff_sectionList') ?? _sectionList;
  }

  SharedPreferences prefs;

  List<String> _sectionList = [];
  List<String> get sectionList => _sectionList;
  set sectionList(List<String> _value) {
    _sectionList = _value;
    prefs.setStringList('ff_sectionList', _value);
  }

  void addToSectionList(String _value) {
    _sectionList.add(_value);
    prefs.setStringList('ff_sectionList', _sectionList);
  }

  void removeFromSectionList(String _value) {
    _sectionList.remove(_value);
    prefs.setStringList('ff_sectionList', _sectionList);
  }

  DocumentReference contentCelebId;

  List<String> uploadedMediaImage = [];

  List<String> uploadedMediaVideo = [];

  DateTime chronoDate;

  bool isSelected = false;

  bool isImageAdded = false;

  bool isVideoAdded = false;
}

LatLng _latLngFromString(String val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}
